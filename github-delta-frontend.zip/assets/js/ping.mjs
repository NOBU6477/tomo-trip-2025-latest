console.info('[PING]', 'ok', new Date().toISOString());
export const ok = true;